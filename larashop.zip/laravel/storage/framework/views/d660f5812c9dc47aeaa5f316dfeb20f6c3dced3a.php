<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <title>Title</title>
    </head>
    <body>
        <div class="container">
            <div class="card mt-5">
                <div class="card-header text-center">
                    Menu Makanan - <strong>Edit Menu</strong> - <a href="https://www.larashop/menu" target="_blank">www.larashop/menu.com</a>
                </div>
                <div class="card-body">
                    <a href="/food" class="btn btn-primary">Kembali</a>
                    <br/>
                    <br/>
                    
 
                    <form method="post" action="/food/update/<?php echo e($foods->id); ?>">
 
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

 
                        <div class="form-group">
                            <label>Menu Makanan</label>
                            <input type="text" name="menu" class="form-control" placeholder="Menu Makanan" value=" <?php echo e($foods->menu); ?>">
 
                            <?php if($errors->has('menu')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('menu')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
 
                        <div class="form-group">
                            <label>Harga</label>
                            <textarea name="harga" class="form-control" placeholder="Harga Makanan"> <?php echo e($foods->harga); ?> </textarea>
 
                             <?php if($errors->has('harga')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('harga')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>

                        <div class="form-group">
                            <label>Gambar</label>
                            <textarea name="gambar" class="form-control" placeholder="Gambar Makanan"> <?php echo e($foods->gambar); ?> </textarea>
 
                             <?php if($errors->has('gambar')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('gambar')); ?>

                                </div>
                            <?php endif; ?>
 
                        </div>
 
                        <div class="form-group">
                            <input type="submit" class="btn btn-success" value="Simpan">
                        </div>
 
                    </form>
 
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/edit_menu.blade.php ENDPATH**/ ?>